# BOT: personal Android AI companion

Milestone 1 (Parts 1-4): native Compose UI with an animated orb, Gemini chat through your own
backend proxy, local Room database and DataStore settings, and on-device text-to-speech.

    app/       Compose UI, ViewModels, wiring
    ai/        Backend client, streaming orchestrator
    memory/    Room (chats, memories) and DataStore settings
    tts/       Text-to-speech engine and speech text cleanup
    backend/   Node proxy that keeps the Gemini key off the phone
    .github/   CI: backend tests, Android unit tests, debug APK

Build: push to GitHub and run the "Build debug APK" workflow, or run
`gradle testDebugUnitTest assembleDebug` with Gradle 9.3.1 and JDK 17.
Backend setup: see backend/README.md.
