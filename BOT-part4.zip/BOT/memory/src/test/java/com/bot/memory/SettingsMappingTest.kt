package com.bot.memory

import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.mutablePreferencesOf
import com.bot.memory.settings.DEFAULT_MODEL
import com.bot.memory.settings.Personality
import com.bot.memory.settings.SettingsKeys
import com.bot.memory.settings.ThemeMode
import com.bot.memory.settings.VoiceMode
import com.bot.memory.settings.toAppSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsMappingTest {
    @Test
    fun emptyPreferencesGiveDefaults() {
        val s = emptyPreferences().toAppSettings()
        assertEquals(DEFAULT_MODEL, s.modelName)
        assertEquals(Personality.BALANCED, s.personality)
        assertEquals(VoiceMode.LOCAL, s.voiceMode)
        assertEquals(ThemeMode.SYSTEM, s.themeMode)
        assertEquals("", s.backendUrl)
        assertTrue(s.memoryEnabled)
        assertTrue(s.ttsEnabled)
        assertNull(s.ttsVoiceName)
    }

    @Test
    fun unknownKeysFallBackToDefaults() {
        val prefs = mutablePreferencesOf(
            SettingsKeys.PERSONALITY to "nonsense",
            SettingsKeys.VOICE_MODE to "warp",
        )
        val s = prefs.toAppSettings()
        assertEquals(Personality.BALANCED, s.personality)
        assertEquals(VoiceMode.LOCAL, s.voiceMode)
    }

    @Test
    fun knownKeysAreRead() {
        val prefs = mutablePreferencesOf(
            SettingsKeys.PERSONALITY to "mentor",
            SettingsKeys.VOICE_MODE to "hybrid",
            SettingsKeys.MODEL_NAME to "custom-model",
        )
        val s = prefs.toAppSettings()
        assertEquals(Personality.MENTOR, s.personality)
        assertEquals(VoiceMode.HYBRID, s.voiceMode)
        assertEquals("custom-model", s.modelName)
    }

    @Test
    fun voiceParametersAreClamped() {
        val prefs = mutablePreferencesOf(
            SettingsKeys.SPEECH_RATE to 9f,
            SettingsKeys.PITCH to 0.01f,
        )
        val s = prefs.toAppSettings()
        assertEquals(2.0f, s.speechRate, 0.0001f)
        assertEquals(0.5f, s.pitch, 0.0001f)
    }

    @Test
    fun blankModelNameFallsBackToDefault() {
        val s = mutablePreferencesOf(SettingsKeys.MODEL_NAME to "   ").toAppSettings()
        assertEquals(DEFAULT_MODEL, s.modelName)
    }
}
