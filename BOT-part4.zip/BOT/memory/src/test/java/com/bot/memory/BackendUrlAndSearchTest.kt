package com.bot.memory

import com.bot.memory.repo.escapeLike
import com.bot.memory.settings.isValidBackendUrl
import com.bot.memory.settings.normalizeBackendUrl
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BackendUrlAndSearchTest {
    @Test
    fun urlIsTrimmedAndTrailingSlashesRemoved() {
        assertEquals("https://example.com", normalizeBackendUrl("  https://example.com//  "))
    }

    @Test
    fun onlyHttpsOrEmptyIsValid() {
        assertTrue(isValidBackendUrl(""))
        assertTrue(isValidBackendUrl("https://bot.example.com"))
        assertFalse(isValidBackendUrl("http://bot.example.com"))
        assertFalse(isValidBackendUrl("https://"))
        assertFalse(isValidBackendUrl("ftp://x"))
        assertFalse(isValidBackendUrl("https://a b"))
    }

    @Test
    fun likeWildcardsAreEscaped() {
        assertEquals("50\\% off\\_now", escapeLike("50% off_now"))
        assertEquals("a\\\\b", escapeLike("a\\b"))
    }
}
