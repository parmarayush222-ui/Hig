package com.bot.memory.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Insert
    suspend fun insert(conversation: ConversationEntity): Long

    @Query("UPDATE conversations SET updatedAt = :time WHERE id = :id")
    suspend fun touch(id: Long, time: Long)

    @Query("UPDATE conversations SET title = :title WHERE id = :id")
    suspend fun rename(id: Long, title: String)

    @Query("UPDATE conversations SET title = :title WHERE id = :id AND title = :defaultTitle")
    suspend fun renameIfTitle(id: Long, defaultTitle: String, title: String)

    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ConversationEntity>>

    @Query("SELECT id FROM conversations ORDER BY updatedAt DESC LIMIT 1")
    suspend fun latestId(): Long?

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM conversations")
    suspend fun deleteAll()
}

@Dao
interface MessageDao {
    @Insert
    suspend fun insert(message: MessageEntity): Long

    @Query("UPDATE messages SET content = :content, status = :status WHERE id = :id")
    suspend fun updateContent(id: Long, content: String, status: String)

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC, id ASC")
    fun observeForConversation(conversationId: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt DESC, id DESC LIMIT :limit")
    suspend fun recent(conversationId: Long, limit: Int): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE content LIKE '%' || :escapedQuery || '%' ESCAPE '\\' ORDER BY createdAt DESC LIMIT :limit")
    suspend fun search(escapedQuery: String, limit: Int): List<MessageEntity>

    @Query("SELECT COUNT(*) FROM messages")
    fun observeCount(): Flow<Int>

    /** Replies left "pending" by a process death can never finish; mark them as failed. */
    @Query("UPDATE messages SET status = 'error', content = CASE WHEN content = '' THEN '(Interrupted)' ELSE content END WHERE status = 'pending'")
    suspend fun failPending()

    @Query("DELETE FROM messages")
    suspend fun deleteAll()
}

@Dao
interface MemoryDao {
    @Insert
    suspend fun insert(memory: MemoryEntity): Long

    @Update
    suspend fun update(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM memories ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE text LIKE '%' || :escapedQuery || '%' ESCAPE '\\' ORDER BY updatedAt DESC LIMIT :limit")
    suspend fun search(escapedQuery: String, limit: Int): List<MemoryEntity>

    @Query("DELETE FROM memories")
    suspend fun deleteAll()
}
