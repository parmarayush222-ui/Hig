package com.bot.memory.repo

import com.bot.memory.db.ConversationDao
import com.bot.memory.db.ConversationEntity
import com.bot.memory.db.MemoryDao
import com.bot.memory.db.MemoryEntity
import com.bot.memory.db.MessageDao
import com.bot.memory.db.MessageEntity
import com.bot.memory.db.MessageStatus
import kotlinx.coroutines.flow.Flow

/** Escapes LIKE wildcards so user text is matched literally (queries use ESCAPE '\'). */
fun escapeLike(raw: String): String =
    raw.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

const val DEFAULT_TITLE = "New chat"

class ChatRepository(
    private val conversations: ConversationDao,
    private val messages: MessageDao,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    fun observeConversations(): Flow<List<ConversationEntity>> = conversations.observeAll()
    fun observeMessages(conversationId: Long): Flow<List<MessageEntity>> =
        messages.observeForConversation(conversationId)
    fun messageCount(): Flow<Int> = messages.observeCount()

    /** Names a still-untitled conversation after its first user message. */
    suspend fun autoTitle(id: Long, firstUserText: String) {
        val title = firstUserText.trim().replace(Regex("\\s+"), " ").take(40)
        if (title.isNotEmpty()) conversations.renameIfTitle(id, DEFAULT_TITLE, title)
    }

    suspend fun createConversation(title: String = DEFAULT_TITLE): Long {
        val now = clock()
        return conversations.insert(ConversationEntity(title = title, createdAt = now, updatedAt = now))
    }

    /** Returns the most recent conversation, creating one if none exists. */
    suspend fun ensureConversation(): Long = conversations.latestId() ?: createConversation()

    suspend fun addMessage(
        conversationId: Long,
        role: String,
        content: String,
        status: String = MessageStatus.OK,
    ): Long {
        val now = clock()
        val id = messages.insert(
            MessageEntity(
                conversationId = conversationId,
                role = role,
                content = content,
                createdAt = now,
                status = status,
            ),
        )
        conversations.touch(conversationId, now)
        return id
    }

    suspend fun updateMessage(id: Long, content: String, status: String = MessageStatus.OK) =
        messages.updateContent(id, content, status)

    /** Most recent messages, returned oldest-first so they can be sent to the model in order. */
    suspend fun recentMessages(conversationId: Long, limit: Int): List<MessageEntity> =
        messages.recent(conversationId, limit).asReversed()

    suspend fun search(query: String, limit: Int = 50): List<MessageEntity> =
        if (query.isBlank()) emptyList() else messages.search(escapeLike(query.trim()), limit)

    suspend fun recoverInterrupted() = messages.failPending()

    suspend fun renameConversation(id: Long, title: String) = conversations.rename(id, title)
    suspend fun deleteConversation(id: Long) = conversations.delete(id)
    suspend fun clearAll() {
        conversations.deleteAll() // messages cascade
    }
}

class MemoryRepository(
    private val dao: MemoryDao,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    fun observeAll(): Flow<List<MemoryEntity>> = dao.observeAll()

    suspend fun add(text: String, category: String = "general"): Long {
        val now = clock()
        return dao.insert(MemoryEntity(text = text.trim(), category = category, createdAt = now, updatedAt = now))
    }

    suspend fun edit(memory: MemoryEntity, newText: String) =
        dao.update(memory.copy(text = newText.trim(), updatedAt = clock()))

    suspend fun delete(id: Long) = dao.delete(id)
    suspend fun deleteAll() = dao.deleteAll()

    suspend fun search(query: String, limit: Int = 10): List<MemoryEntity> =
        if (query.isBlank()) emptyList() else dao.search(escapeLike(query.trim()), limit)
}
