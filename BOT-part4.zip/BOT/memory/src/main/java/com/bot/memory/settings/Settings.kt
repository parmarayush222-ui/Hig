package com.bot.memory.settings

/** Short personality configuration; screens and services never hardcode tone. */
enum class Personality(val key: String, val label: String, val systemPrompt: String) {
    MENTOR(
        "mentor", "Mentor",
        "You are BOT, a supportive mentor. Guide the user with clear reasoning, ask a useful question when it helps them learn, and be honest about mistakes.",
    ),
    FRIEND(
        "friend", "Friend",
        "You are BOT, a warm, casual friend. Keep replies short and natural, and be honest rather than flattering.",
    ),
    PROFESSIONAL(
        "professional", "Professional",
        "You are BOT, a precise professional assistant. Be concise, structured and neutral in tone.",
    ),
    BALANCED(
        "balanced", "Balanced",
        "You are BOT, a helpful, concise personal assistant. Be clear and honest, and say so when you cannot do something or are unsure.",
    );

    companion object {
        fun fromKey(key: String?): Personality = entries.firstOrNull { it.key == key } ?: BALANCED
    }
}

enum class VoiceMode(val key: String) {
    LOCAL("local"), CLOUD("cloud"), HYBRID("hybrid");

    companion object {
        fun fromKey(key: String?): VoiceMode = entries.firstOrNull { it.key == key } ?: LOCAL
    }
}

enum class ThemeMode(val key: String) {
    SYSTEM("system"), LIGHT("light"), DARK("dark");

    companion object {
        fun fromKey(key: String?): ThemeMode = entries.firstOrNull { it.key == key } ?: SYSTEM
    }
}

const val DEFAULT_MODEL = "gemini-3.5-flash"

data class AppSettings(
    val backendUrl: String = "",
    val backendToken: String = "",
    val modelName: String = DEFAULT_MODEL,
    val personality: Personality = Personality.BALANCED,
    val voiceMode: VoiceMode = VoiceMode.LOCAL,
    val ttsEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.0f,
    val ttsVoiceName: String? = null,
    val ttsLanguageTag: String = "",
    val memoryEnabled: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val launchCount: Int = 0,
)

/** Trims and removes trailing slashes. */
fun normalizeBackendUrl(raw: String): String = raw.trim().trimEnd('/')

/** Only https is accepted: Android blocks cleartext http by default. Empty means "not configured". */
fun isValidBackendUrl(url: String): Boolean =
    url.isEmpty() || (url.startsWith("https://") && url.length > "https://".length && !url.contains(' '))
