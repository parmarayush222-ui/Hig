package com.bot.memory.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.IOException
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

object SettingsKeys {
    val BACKEND_URL = stringPreferencesKey("backend_url")
    val BACKEND_TOKEN = stringPreferencesKey("backend_token")
    val MODEL_NAME = stringPreferencesKey("model_name")
    val PERSONALITY = stringPreferencesKey("personality")
    val VOICE_MODE = stringPreferencesKey("voice_mode")
    val TTS_ENABLED = booleanPreferencesKey("tts_enabled")
    val SPEECH_RATE = floatPreferencesKey("speech_rate")
    val PITCH = floatPreferencesKey("pitch")
    val TTS_VOICE = stringPreferencesKey("tts_voice")
    val TTS_LANGUAGE = stringPreferencesKey("tts_language")
    val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val LAUNCH_COUNT = intPreferencesKey("launch_count")
}

const val MIN_VOICE_PARAM = 0.5f
const val MAX_VOICE_PARAM = 2.0f

private fun Float.clampVoice() = coerceIn(MIN_VOICE_PARAM, MAX_VOICE_PARAM)

/** Pure mapping so it can be unit-tested without Android. */
fun Preferences.toAppSettings(): AppSettings = AppSettings(
    backendUrl = this[SettingsKeys.BACKEND_URL] ?: "",
    backendToken = this[SettingsKeys.BACKEND_TOKEN] ?: "",
    modelName = this[SettingsKeys.MODEL_NAME]?.takeIf { it.isNotBlank() } ?: DEFAULT_MODEL,
    personality = Personality.fromKey(this[SettingsKeys.PERSONALITY]),
    voiceMode = VoiceMode.fromKey(this[SettingsKeys.VOICE_MODE]),
    ttsEnabled = this[SettingsKeys.TTS_ENABLED] ?: true,
    speechRate = (this[SettingsKeys.SPEECH_RATE] ?: 1.0f).clampVoice(),
    pitch = (this[SettingsKeys.PITCH] ?: 1.0f).clampVoice(),
    ttsVoiceName = this[SettingsKeys.TTS_VOICE]?.takeIf { it.isNotBlank() },
    ttsLanguageTag = this[SettingsKeys.TTS_LANGUAGE] ?: "",
    memoryEnabled = this[SettingsKeys.MEMORY_ENABLED] ?: true,
    themeMode = ThemeMode.fromKey(this[SettingsKeys.THEME_MODE]),
    launchCount = this[SettingsKeys.LAUNCH_COUNT] ?: 0,
)

private val Context.botDataStore: DataStore<Preferences> by preferencesDataStore(name = "bot_settings")

class SettingsRepository(private val dataStore: DataStore<Preferences>) {

    val settings: Flow<AppSettings> = dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it.toAppSettings() }

    /** Returns false (and stores nothing) when the URL is not a valid https URL. */
    suspend fun setBackendUrl(raw: String): Boolean {
        val url = normalizeBackendUrl(raw)
        if (!isValidBackendUrl(url)) return false
        dataStore.edit { it[SettingsKeys.BACKEND_URL] = url }
        return true
    }

    /** The shared app token (not the Gemini key). Entered by the user, kept in app-private storage. */
    suspend fun setBackendToken(raw: String) {
        dataStore.edit { it[SettingsKeys.BACKEND_TOKEN] = raw.trim() }
    }

    suspend fun setModelName(name: String) {
        if (name.isNotBlank()) dataStore.edit { it[SettingsKeys.MODEL_NAME] = name.trim() }
    }

    suspend fun setPersonality(value: Personality) =
        dataStore.edit { it[SettingsKeys.PERSONALITY] = value.key }.let { }

    suspend fun setVoiceMode(value: VoiceMode) =
        dataStore.edit { it[SettingsKeys.VOICE_MODE] = value.key }.let { }

    suspend fun setTtsEnabled(value: Boolean) =
        dataStore.edit { it[SettingsKeys.TTS_ENABLED] = value }.let { }

    suspend fun setSpeechRate(value: Float) =
        dataStore.edit { it[SettingsKeys.SPEECH_RATE] = value.clampVoice() }.let { }

    suspend fun setPitch(value: Float) =
        dataStore.edit { it[SettingsKeys.PITCH] = value.clampVoice() }.let { }

    suspend fun setTtsVoice(name: String?) {
        dataStore.edit {
            if (name.isNullOrBlank()) it.remove(SettingsKeys.TTS_VOICE) else it[SettingsKeys.TTS_VOICE] = name
        }
    }

    suspend fun setTtsLanguage(tag: String) =
        dataStore.edit { it[SettingsKeys.TTS_LANGUAGE] = tag }.let { }

    suspend fun setMemoryEnabled(value: Boolean) =
        dataStore.edit { it[SettingsKeys.MEMORY_ENABLED] = value }.let { }

    suspend fun setThemeMode(value: ThemeMode) =
        dataStore.edit { it[SettingsKeys.THEME_MODE] = value.key }.let { }

    suspend fun incrementLaunchCount() {
        dataStore.edit { it[SettingsKeys.LAUNCH_COUNT] = (it[SettingsKeys.LAUNCH_COUNT] ?: 0) + 1 }
    }

    companion object {
        fun from(context: Context) = SettingsRepository(context.applicationContext.botDataStore)
    }
}
