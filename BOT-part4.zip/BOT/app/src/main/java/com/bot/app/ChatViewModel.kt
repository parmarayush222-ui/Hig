package com.bot.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bot.ai.BotPhase
import com.bot.app.ui.OrbState
import com.bot.memory.db.ConversationEntity
import com.bot.memory.db.MessageEntity
import com.bot.memory.settings.AppSettings
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(private val container: AppContainer) : ViewModel() {

    private val conversationId = MutableStateFlow<Long?>(null)
    private val whileSubscribed = SharingStarted.WhileSubscribed(5_000)

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = conversationId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else container.chat.observeMessages(id)
        }
        .stateIn(viewModelScope, whileSubscribed, emptyList())

    val settings: StateFlow<AppSettings> = container.settings.settings
        .stateIn(viewModelScope, whileSubscribed, AppSettings())

    val busy: StateFlow<Boolean> = container.orchestrator.phase
        .map { it != BotPhase.IDLE }
        .stateIn(viewModelScope, whileSubscribed, false)

    val speaking: StateFlow<Boolean> = container.tts.isSpeaking
    val ttsNotice: StateFlow<String?> = container.tts.notice

    val orbState: StateFlow<OrbState> =
        combine(container.orchestrator.phase, container.tts.isSpeaking) { phase, speaking ->
            when {
                speaking -> OrbState.SPEAKING
                phase == BotPhase.THINKING -> OrbState.THINKING
                phase == BotPhase.STREAMING -> OrbState.RESPONDING
                else -> OrbState.IDLE
            }
        }.stateIn(viewModelScope, whileSubscribed, OrbState.IDLE)

    val conversations: StateFlow<List<ConversationEntity>> = container.chat.observeConversations()
        .stateIn(viewModelScope, whileSubscribed, emptyList())

    val searchQuery = MutableStateFlow("")

    @OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
    val searchResults: StateFlow<List<MessageEntity>> = searchQuery
        .debounce(250)
        .mapLatest { container.chat.search(it) }
        .stateIn(viewModelScope, whileSubscribed, emptyList())

    private var sendJob: Job? = null

    init {
        viewModelScope.launch { conversationId.value = container.chat.ensureConversation() }
    }

    fun send(text: String) {
        val id = conversationId.value ?: return
        if (text.isBlank() || sendJob?.isActive == true) return
        container.tts.stop()
        sendJob = viewModelScope.launch {
            val reply = container.orchestrator.send(id, text.trim())
            val s = container.settings.settings.first()
            if (reply != null && s.ttsEnabled) container.tts.speak(reply, s.toVoiceParams())
        }
    }

    /** Stops both a reply that is still being written and any speech. */
    fun stop() {
        sendJob?.cancel()
        container.tts.stop()
    }

    fun speak(text: String) {
        viewModelScope.launch {
            container.tts.speak(text, container.settings.settings.first().toVoiceParams())
        }
    }

    fun stopSpeaking() = container.tts.stop()

    fun newChat() {
        if (sendJob?.isActive == true) return
        container.tts.stop()
        viewModelScope.launch { conversationId.value = container.chat.createConversation() }
    }

    fun openConversation(id: Long) {
        if (sendJob?.isActive == true) return
        container.tts.stop()
        conversationId.value = id
    }

    fun deleteConversation(id: Long) {
        if (sendJob?.isActive == true && conversationId.value == id) return
        viewModelScope.launch {
            container.chat.deleteConversation(id)
            if (conversationId.value == id) conversationId.value = container.chat.ensureConversation()
        }
    }
}
