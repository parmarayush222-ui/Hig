package com.bot.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bot.ai.ConnectionStatus
import com.bot.app.SettingsViewModel
import com.bot.memory.settings.Personality
import com.bot.memory.settings.ThemeMode
import com.bot.tts.TtsStatus
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val connection by vm.connection.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    val voices by vm.voices.collectAsStateWithLifecycle()
    val ttsStatus by vm.ttsStatus.collectAsStateWithLifecycle()
    val ttsNotice by vm.ttsNotice.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var url by remember(settings.backendUrl) { mutableStateOf(settings.backendUrl) }
    var token by remember(settings.backendToken) { mutableStateOf(settings.backendToken) }
    var model by remember(settings.modelName) { mutableStateOf(settings.modelName) }
    var rate by remember(settings.speechRate) { mutableFloatStateOf(settings.speechRate) }
    var pitch by remember(settings.pitch) { mutableFloatStateOf(settings.pitch) }
    var allLanguages by rememberSaveable { mutableStateOf(false) }

    val deviceLanguage = remember { Locale.getDefault().language }
    val shownVoices = remember(voices, allLanguages) {
        voices.filter { allLanguages || it.languageTag.substringBefore('-') == deviceLanguage }.take(40)
    }

    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Back") }
            Text("Settings", style = MaterialTheme.typography.titleLarge)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            Section("Backend") {
                OutlinedTextField(
                    value = url, onValueChange = { url = it }, singleLine = true,
                    label = { Text("Backend URL (https://…)") }, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = token, onValueChange = { token = it }, singleLine = true,
                    label = { Text("App token") }, visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.saveBackend(url, token) }) { Text("Save") }
                    OutlinedButton(onClick = { vm.testConnection() }) { Text("Test connection") }
                }
                Text(connectionText(connection, notice), style = MaterialTheme.typography.bodySmall)
            }

            Section("Model") {
                OutlinedTextField(
                    value = model, onValueChange = { model = it }, singleLine = true,
                    label = { Text("Gemini model name") }, modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = { vm.setModel(model) },
                    enabled = model.isNotBlank() && model.trim() != settings.modelName,
                ) { Text("Use this model") }
                val allowed = (connection as? ConnectionStatus.Connected)?.models.orEmpty()
                if (allowed.isNotEmpty()) {
                    Text("Allowed by your backend:", style = MaterialTheme.typography.bodySmall)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        allowed.forEach { name ->
                            FilterChip(
                                selected = name == settings.modelName,
                                onClick = { model = name; vm.setModel(name) },
                                label = { Text(name) },
                            )
                        }
                    }
                }
            }

            Section("Personality") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Personality.entries.forEach { p ->
                        FilterChip(
                            selected = p == settings.personality,
                            onClick = { vm.setPersonality(p) },
                            label = { Text(p.label) },
                        )
                    }
                }
                Text(settings.personality.systemPrompt, style = MaterialTheme.typography.bodySmall)
            }

            Section("Voice") {
                SwitchRow("Speak replies aloud", settings.ttsEnabled) { vm.setTtsEnabled(it) }
                Text(
                    "Engine: this phone's built-in text-to-speech. Cloud voices and hands-free listening arrive in Milestone 2.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    when (val s = ttsStatus) {
                        TtsStatus.Initializing -> "Starting the speech engine…"
                        TtsStatus.Ready -> "Speech engine ready (${voices.size} voices installed)."
                        is TtsStatus.Unavailable -> s.reason
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
                ttsNotice?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }

                Text("Speed: ${"%.2f".format(rate)}×")
                Slider(
                    value = rate, onValueChange = { rate = it },
                    valueRange = 0.5f..2f, onValueChangeFinished = { vm.setSpeechRate(rate) },
                )
                Text("Pitch: ${"%.2f".format(pitch)}")
                Slider(
                    value = pitch, onValueChange = { pitch = it },
                    valueRange = 0.5f..2f, onValueChangeFinished = { vm.setPitch(pitch) },
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !allLanguages, onClick = { allLanguages = false }, label = { Text("My language") })
                    FilterChip(selected = allLanguages, onClick = { allLanguages = true }, label = { Text("All languages") })
                }
                VoiceRow("Automatic (device default)", "Uses your phone's default voice", settings.ttsVoiceName == null) {
                    vm.setVoice(null)
                }
                shownVoices.forEach { v ->
                    VoiceRow(
                        title = "${v.displayLanguage} · ${v.name}",
                        subtitle = if (v.offline) "On-device" else "Online (needs internet)",
                        selected = settings.ttsVoiceName == v.name,
                    ) { vm.setVoice(v.name) }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.previewVoice() }) { Text("Preview voice") }
                    if (speaking) OutlinedButton(onClick = { vm.stopPreview() }) { Text("Stop") }
                }
                OutlinedButton(onClick = {
                    try {
                        context.startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                    } catch (e: ActivityNotFoundException) {
                        context.startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                }) { Text("Manage voice data") }
            }

            Section("Memory") {
                SwitchRow("Remember things between chats", settings.memoryEnabled) { vm.setMemoryEnabled(it) }
                Text(
                    "Chats are saved on this phone. Long-term memory that BOT recalls and lets you edit arrives in Milestone 5; this switch is saved for then.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            Section("Theme") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = mode == settings.themeMode,
                            onClick = { vm.setTheme(mode) },
                            label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun VoiceRow(title: String, subtitle: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().selectable(selected = selected, onClick = onSelect, role = Role.RadioButton),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Column(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp)) {
            Text(title)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun connectionText(status: ConnectionStatus?, notice: String?): String = when (status) {
    null -> notice ?: "Enter your backend URL and token, then tap Test connection."
    ConnectionStatus.Checking -> "Checking…"
    is ConnectionStatus.Connected ->
        if (status.geminiConfigured) "Connected. Models: ${status.models.joinToString()}"
        else "Connected, but the server has no Gemini key configured."
    is ConnectionStatus.Failed -> status.error.userMessage
}
