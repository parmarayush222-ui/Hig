package com.bot.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.bot.app.ui.BotTheme
import com.bot.app.ui.ChatScreen
import com.bot.app.ui.HistoryScreen
import com.bot.app.ui.SettingsScreen
import com.bot.memory.settings.AppSettings
import com.bot.memory.settings.ThemeMode

private enum class Screen { CHAT, SETTINGS, HISTORY }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as BotApplication).container
        setContent {
            val settings by container.settings.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
            val dark = when (settings.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            // Keep system bar icons readable when the chosen theme differs from the system theme.
            DisposableEffect(dark) {
                val style = if (dark) {
                    SystemBarStyle.dark(Color.TRANSPARENT)
                } else {
                    SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            BotTheme(dark) {
                Surface(Modifier.fillMaxSize()) { BotApp(container) }
            }
        }
    }
}

@Composable
private fun BotApp(container: AppContainer) {
    val chatVm: ChatViewModel = viewModel(
        factory = viewModelFactory { initializer { ChatViewModel(container) } },
    )
    val settingsVm: SettingsViewModel = viewModel(
        factory = viewModelFactory { initializer { SettingsViewModel(container) } },
    )
    var screen by rememberSaveable { mutableStateOf(Screen.CHAT) }
    BackHandler(enabled = screen != Screen.CHAT) { screen = Screen.CHAT }

    when (screen) {
        Screen.CHAT -> ChatScreen(
            vm = chatVm,
            onOpenSettings = { screen = Screen.SETTINGS },
            onOpenHistory = { screen = Screen.HISTORY },
        )
        Screen.SETTINGS -> SettingsScreen(vm = settingsVm, onBack = { screen = Screen.CHAT })
        Screen.HISTORY -> HistoryScreen(vm = chatVm, onBack = { screen = Screen.CHAT }, onOpened = { screen = Screen.CHAT })
    }
}
