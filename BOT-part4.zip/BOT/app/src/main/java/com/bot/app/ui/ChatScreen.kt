package com.bot.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bot.app.ChatViewModel
import com.bot.memory.db.MessageEntity
import com.bot.memory.db.MessageStatus
import com.bot.memory.db.Role

@Composable
fun ChatScreen(vm: ChatViewModel, onOpenSettings: () -> Unit, onOpenHistory: () -> Unit) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val orb by vm.orbState.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    val ttsNotice by vm.ttsNotice.collectAsStateWithLifecycle()

    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val configured = settings.backendUrl.isNotBlank() && settings.backendToken.isNotBlank()

    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) listState.scrollToItem(messages.lastIndex)
    }

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("BOT", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenHistory) { Text("History") }
            TextButton(onClick = onOpenSettings) { Text("Settings") }
        }

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            BotOrb(
                state = orb,
                modifier = Modifier.clickable(
                    enabled = orb == OrbState.SPEAKING,
                    onClickLabel = "Stop speaking",
                ) { vm.stopSpeaking() },
            )
        }
        Text(
            orb.label,
            style = MaterialTheme.typography.labelLarge,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        ttsNotice?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
        if (!configured) SetupBanner(onOpenSettings)

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                Text(
                    "Say hello to BOT.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center),
                )
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(messages, key = { it.id }) { m -> MessageBubble(m, onSpeak = vm::speak) }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text(if (busy) "BOT is replying…" else "Message BOT") },
                modifier = Modifier.weight(1f),
                maxLines = 4,
            )
            if (busy || speaking) {
                Button(onClick = { vm.stop() }) { Text("Stop") }
            } else {
                Button(
                    onClick = { vm.send(input); input = "" },
                    enabled = input.isNotBlank(),
                ) { Text("Send") }
            }
        }
    }
}

@Composable
private fun SetupBanner(onOpenSettings: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("BOT isn't connected yet.", style = MaterialTheme.typography.titleSmall)
            Text(
                "Enter your backend URL and app token in Settings to start chatting.",
                style = MaterialTheme.typography.bodySmall,
            )
            TextButton(onClick = onOpenSettings) { Text("Open Settings") }
        }
    }
}

@Composable
private fun MessageBubble(m: MessageEntity, onSpeak: (String) -> Unit) {
    val isUser = m.role == Role.USER
    val isError = m.status == MessageStatus.ERROR
    val waiting = m.status == MessageStatus.PENDING && m.content.isEmpty()
    val colors = MaterialTheme.colorScheme
    val (background, foreground) = when {
        isError -> colors.errorContainer to colors.onErrorContainer
        isUser -> colors.primaryContainer to colors.onPrimaryContainer
        else -> colors.surfaceVariant to colors.onSurfaceVariant
    }
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
    ) {
        Surface(
            color = background,
            contentColor = foreground,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            SelectionContainer {
                Text(if (waiting) "…" else m.content, modifier = Modifier.padding(12.dp))
            }
        }
        if (!isUser && !isError && m.status == MessageStatus.OK && m.content.isNotBlank()) {
            TextButton(onClick = { onSpeak(m.content) }) {
                Text("Speak", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
