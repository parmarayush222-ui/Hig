package com.bot.app.ui

import android.content.Context
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

/** What BOT is doing right now. Listening and executing join this list in later milestones. */
enum class OrbState(val label: String) {
    IDLE("Ready"),
    THINKING("Thinking…"),
    RESPONDING("Responding…"),
    SPEAKING("Speaking…"),
}

/** Respects the system "remove animations" setting. */
private fun animationsEnabled(context: Context): Boolean =
    Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) != 0f

@Composable
fun BotOrb(state: OrbState, modifier: Modifier = Modifier, diameter: Dp = 110.dp) {
    val context = LocalContext.current
    val animate = remember { animationsEnabled(context) }
    val transition = rememberInfiniteTransition(label = "orb")
    // One seamless loop. Every motion below uses whole cycles per loop, so there is no jump.
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "phase",
    )
    val energy by animateFloatAsState(
        targetValue = when (state) {
            OrbState.IDLE -> 0.25f
            OrbState.THINKING -> 0.7f
            OrbState.RESPONDING -> 0.85f
            OrbState.SPEAKING -> 1f
        },
        animationSpec = tween(400),
        label = "energy",
    )
    val core = MaterialTheme.colorScheme.primary
    val glow = MaterialTheme.colorScheme.tertiary

    Canvas(
        modifier
            .size(diameter)
            .semantics { contentDescription = "BOT status: ${state.label}" },
    ) {
        val center = this.center
        val radius = this.size.minDimension / 2f
        val p = if (animate) phase else 0f
        val twoPi = (2.0 * PI).toFloat()

        val breathe = 1f + 0.05f * (0.4f + energy) * sin(twoPi * p)
        val pulse = if (state == OrbState.SPEAKING) 0.07f * sin(twoPi * 4f * p) else 0f
        val scale = breathe + pulse

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(glow.copy(alpha = 0.10f + 0.35f * energy), Color.Transparent),
                center = center,
                radius = radius,
            ),
            radius = radius,
            center = center,
        )

        val coreRadius = radius * 0.55f * scale
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(core, core.copy(alpha = 0.35f)),
                center = center,
                radius = coreRadius,
            ),
            radius = coreRadius,
            center = center,
        )

        val spins = when (state) {
            OrbState.IDLE -> 0f
            OrbState.THINKING -> 2f
            OrbState.RESPONDING, OrbState.SPEAKING -> 1f
        }
        val ringRadius = radius * 0.8f
        val stroke = Stroke(width = radius * 0.045f, cap = StrokeCap.Round)
        val topLeft = Offset(center.x - ringRadius, center.y - ringRadius)
        val arcSize = Size(ringRadius * 2f, ringRadius * 2f)

        rotate(degrees = 360f * spins * p, pivot = center) {
            drawArc(
                color = core,
                startAngle = 0f,
                sweepAngle = 90f + 90f * energy,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = stroke,
            )
        }
        rotate(degrees = -360f * spins * p + 180f, pivot = center) {
            drawArc(
                color = glow,
                startAngle = 0f,
                sweepAngle = 60f + 60f * energy,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = stroke,
            )
        }
    }
}
