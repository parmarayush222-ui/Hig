package com.bot.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF00E5FF),
    onPrimary = Color(0xFF003238),
    primaryContainer = Color(0xFF004F58),
    onPrimaryContainer = Color(0xFFB8F4FF),
    secondary = Color(0xFF7C8CFF),
    tertiary = Color(0xFFB388FF),
    background = Color(0xFF0B1020),
    onBackground = Color(0xFFE6E9F5),
    surface = Color(0xFF0B1020),
    onSurface = Color(0xFFE6E9F5),
    surfaceVariant = Color(0xFF1A2238),
    onSurfaceVariant = Color(0xFFC5CAE0),
    error = Color(0xFFFF6B6B),
    errorContainer = Color(0xFF5C1F1F),
    onErrorContainer = Color(0xFFFFD9D9),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF00677A),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFC2F1FF),
    onPrimaryContainer = Color(0xFF001F26),
    secondary = Color(0xFF4A58C9),
    tertiary = Color(0xFF6A4FC4),
    background = Color(0xFFF6F8FF),
    onBackground = Color(0xFF191C24),
    surface = Color(0xFFF6F8FF),
    onSurface = Color(0xFF191C24),
    surfaceVariant = Color(0xFFE1E6F5),
    onSurfaceVariant = Color(0xFF434858),
    error = Color(0xFFB3261E),
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = Color(0xFF410E0B),
)

@Composable
fun BotTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
