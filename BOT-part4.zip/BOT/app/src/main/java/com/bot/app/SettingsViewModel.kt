package com.bot.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bot.ai.ConnectionStatus
import com.bot.memory.settings.AppSettings
import com.bot.memory.settings.Personality
import com.bot.memory.settings.ThemeMode
import com.bot.tts.TtsStatus
import com.bot.tts.VoiceInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val PREVIEW_TEXT = "Hello, I'm BOT. This is how I sound with these settings."

class SettingsViewModel(private val container: AppContainer) : ViewModel() {

    val settings: StateFlow<AppSettings> = container.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    val voices: StateFlow<List<VoiceInfo>> = container.tts.voices
    val ttsStatus: StateFlow<TtsStatus> = container.tts.status
    val ttsNotice: StateFlow<String?> = container.tts.notice
    val speaking: StateFlow<Boolean> = container.tts.isSpeaking

    private val _connection = MutableStateFlow<ConnectionStatus?>(null)
    val connection: StateFlow<ConnectionStatus?> = _connection.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    fun saveBackend(url: String, token: String) {
        viewModelScope.launch {
            val ok = container.settings.setBackendUrl(url)
            container.settings.setBackendToken(token)
            _notice.value = if (ok) "Saved." else "The URL must start with https://"
        }
    }

    fun testConnection() {
        viewModelScope.launch {
            _connection.value = ConnectionStatus.Checking
            val s = container.settings.settings.first()
            _connection.value = container.connectionChecker.check(s.backendUrl, s.backendToken)
        }
    }

    fun setModel(name: String) = launch { container.settings.setModelName(name) }
    fun setPersonality(value: Personality) = launch { container.settings.setPersonality(value) }
    fun setTtsEnabled(value: Boolean) = launch { container.settings.setTtsEnabled(value) }
    fun setSpeechRate(value: Float) = launch { container.settings.setSpeechRate(value) }
    fun setPitch(value: Float) = launch { container.settings.setPitch(value) }
    fun setVoice(name: String?) = launch { container.settings.setTtsVoice(name) }
    fun setMemoryEnabled(value: Boolean) = launch { container.settings.setMemoryEnabled(value) }
    fun setTheme(value: ThemeMode) = launch { container.settings.setThemeMode(value) }

    fun previewVoice() {
        viewModelScope.launch {
            container.tts.speak(PREVIEW_TEXT, container.settings.settings.first().toVoiceParams())
        }
    }

    fun stopPreview() = container.tts.stop()

    private fun launch(block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }
}
