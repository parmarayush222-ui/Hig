package com.bot.app

import android.content.Context
import com.bot.ai.BackendChatClient
import com.bot.ai.ChatOrchestrator
import com.bot.ai.ConnectionChecker
import com.bot.memory.db.BotDatabase
import com.bot.memory.repo.ChatRepository
import com.bot.memory.repo.MemoryRepository
import com.bot.memory.settings.AppSettings
import com.bot.memory.settings.SettingsRepository
import com.bot.tts.AndroidTtsEngine
import com.bot.tts.TtsEngine
import com.bot.tts.VoiceParams

/** Simple manual dependency container (no DI framework to keep the build lean). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val database: BotDatabase by lazy { BotDatabase.create(appContext) }
    val chat: ChatRepository by lazy {
        ChatRepository(database.conversationDao(), database.messageDao())
    }
    val memories: MemoryRepository by lazy { MemoryRepository(database.memoryDao()) }
    val settings: SettingsRepository by lazy { SettingsRepository.from(appContext) }

    val connectionChecker: ConnectionChecker by lazy { ConnectionChecker() }
    val orchestrator: ChatOrchestrator by lazy {
        ChatOrchestrator(chat, settings, BackendChatClient())
    }

    /** Created on first use, which happens on the main thread when a ViewModel is built. */
    val tts: TtsEngine by lazy { AndroidTtsEngine(appContext) }
}

fun AppSettings.toVoiceParams() = VoiceParams(
    rate = speechRate,
    pitch = pitch,
    voiceName = ttsVoiceName,
    languageTag = ttsLanguageTag,
)
