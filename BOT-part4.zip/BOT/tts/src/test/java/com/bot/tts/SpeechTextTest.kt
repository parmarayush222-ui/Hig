package com.bot.tts

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechTextTest {
    @Test
    fun plainTextIsUnchanged() {
        assertEquals("Hello there. How are you?", cleanForSpeech("Hello there. How are you?"))
    }

    @Test
    fun markdownSymbolsAreRemoved() {
        assertEquals("Title\nBold and italic", cleanForSpeech("# Title\n**Bold** and *italic*"))
        assertEquals("one\ntwo", cleanForSpeech("- one\n* two"))
        assertEquals("use the tool", cleanForSpeech("use the `tool`"))
    }

    @Test
    fun linksAndUrlsAreShortened() {
        assertEquals("see the docs", cleanForSpeech("see [the docs](https://example.com/x)"))
        assertEquals("open link now", cleanForSpeech("open https://example.com/very/long/path now"))
    }

    @Test
    fun codeBlocksAreOmitted() {
        val out = cleanForSpeech("Before\n```kotlin\nval x = 1\n```\nAfter")
        assertTrue(out.contains("code omitted"))
        assertFalse(out.contains("val x"))
    }

    @Test
    fun snakeCaseSurvivesButEmphasisUnderscoresGo() {
        assertEquals("file_name", cleanForSpeech("file_name"))
        assertEquals("word", cleanForSpeech("_word_"))
    }

    @Test
    fun shortTextIsOneChunk() {
        assertEquals(listOf("Hi there."), splitForSpeech("  Hi there.  ", 100))
    }

    @Test
    fun longTextSplitsAtSentences() {
        val text = ("Sentence one. ".repeat(20)).trim()
        val chunks = splitForSpeech(text, 100)
        assertTrue(chunks.size > 1)
        assertTrue(chunks.all { it.length <= 100 })
        assertTrue(chunks.all { it.endsWith(".") })
        assertEquals(text, chunks.joinToString(" "))
    }

    @Test
    fun textWithoutSpacesIsHardCut() {
        val chunks = splitForSpeech("a".repeat(250), 100)
        assertEquals(listOf(100, 100, 50), chunks.map { it.length })
    }

    @Test
    fun noWordIsLostWhenSplittingAtSpaces() {
        val text = (1..80).joinToString(" ") { "word$it" }
        val chunks = splitForSpeech(text, 120)
        assertTrue(chunks.all { it.length <= 120 })
        assertEquals(text, chunks.joinToString(" "))
    }
}
