package com.bot.tts

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/**
 * Speech through Android's built-in TextToSpeech. Whether a voice works offline depends on the
 * installed engine and voice data; [VoiceInfo.offline] reports what the engine says, nothing more.
 * Create it on the main thread.
 */
class AndroidTtsEngine(context: Context) : TtsEngine {

    private val appContext = context.applicationContext
    private val lock = Any()
    private val active = HashSet<String>()
    private val counter = AtomicLong()
    private var engine: TextToSpeech? = null
    private var pending: Pair<String, VoiceParams>? = null
    private var rawVoices: List<Voice> = emptyList()

    private val _status = MutableStateFlow<TtsStatus>(TtsStatus.Initializing)
    override val status: StateFlow<TtsStatus> = _status.asStateFlow()

    private val _speaking = MutableStateFlow(false)
    override val isSpeaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private val _voices = MutableStateFlow<List<VoiceInfo>>(emptyList())
    override val voices: StateFlow<List<VoiceInfo>> = _voices.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    override val notice: StateFlow<String?> = _notice.asStateFlow()

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) = Unit
        override fun onDone(utteranceId: String?) = finish(utteranceId)

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) = finish(utteranceId)

        override fun onError(utteranceId: String?, errorCode: Int) {
            _notice.value = "The speech engine reported an error (code $errorCode)."
            finish(utteranceId)
        }

        override fun onStop(utteranceId: String?, interrupted: Boolean) = finish(utteranceId)
    }

    init {
        engine = TextToSpeech(appContext) { code -> onEngineInit(code) }
    }

    private fun onEngineInit(code: Int) {
        val tts = engine
        if (code != TextToSpeech.SUCCESS || tts == null) {
            _status.value = TtsStatus.Unavailable(
                "No speech engine could start. Install or enable one (for example Speech Services by Google) in your phone's text-to-speech settings.",
            )
            return
        }
        tts.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
        )
        tts.setOnUtteranceProgressListener(listener)
        loadVoices(tts)
        _status.value = TtsStatus.Ready
        val queued = synchronized(lock) { pending.also { pending = null } }
        if (queued != null) speak(queued.first, queued.second)
    }

    private fun loadVoices(tts: TextToSpeech) {
        rawVoices = try {
            tts.voices?.toList().orEmpty()
        } catch (e: Exception) {
            emptyList()
        }
        _voices.value = rawVoices
            .filter { it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true }
            .map {
                VoiceInfo(
                    name = it.name,
                    languageTag = it.locale.toLanguageTag(),
                    displayLanguage = it.locale.displayName,
                    offline = !it.isNetworkConnectionRequired,
                    quality = it.quality,
                )
            }
            .sortedWith(compareBy({ it.displayLanguage }, { !it.offline }, { it.name }))
    }

    override fun speak(text: String, params: VoiceParams) {
        val clean = cleanForSpeech(text)
        if (clean.isEmpty()) return
        val tts = engine
        when (_status.value) {
            TtsStatus.Initializing -> {
                synchronized(lock) { pending = clean to params }
                return
            }
            is TtsStatus.Unavailable -> {
                _notice.value = "Speech isn't available on this phone right now."
                return
            }
            TtsStatus.Ready -> Unit
        }
        if (tts == null) return

        _notice.value = null
        tts.stop()
        synchronized(lock) { active.clear() }
        _speaking.value = false

        if (!selectVoice(tts, params)) return
        tts.setSpeechRate(params.rate.coerceIn(0.5f, 2.0f))
        tts.setPitch(params.pitch.coerceIn(0.5f, 2.0f))

        val maxLen = minOf(3500, TextToSpeech.getMaxSpeechInputLength() - 100)
        splitForSpeech(clean, maxLen).forEachIndexed { index, chunk ->
            val id = "bot-${counter.incrementAndGet()}"
            synchronized(lock) {
                active += id
                _speaking.value = true
            }
            val mode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            if (tts.speak(chunk, mode, null, id) != TextToSpeech.SUCCESS) {
                _notice.value = "The speech engine refused to start."
                finish(id)
            }
        }
    }

    private fun selectVoice(tts: TextToSpeech, params: VoiceParams): Boolean {
        val voice = params.voiceName?.let { name -> rawVoices.firstOrNull { it.name == name } }
        if (voice != null && tts.setVoice(voice) == TextToSpeech.SUCCESS) return true

        val locale = if (params.languageTag.isNotBlank()) {
            Locale.forLanguageTag(params.languageTag)
        } else {
            Locale.getDefault()
        }
        if (languageOk(tts.setLanguage(locale))) return true
        if (languageOk(tts.setLanguage(Locale.US))) {
            _notice.value = "Speech for your language isn't installed, so BOT is using English. Add voice data in Settings."
            return true
        }
        _notice.value = "No installed voice can speak. Add voice data in your phone's text-to-speech settings."
        return false
    }

    private fun languageOk(result: Int) = result >= TextToSpeech.LANG_AVAILABLE

    private fun finish(id: String?) {
        synchronized(lock) {
            if (id != null) active -= id
            _speaking.value = active.isNotEmpty()
        }
    }

    override fun stop() {
        engine?.stop()
        synchronized(lock) {
            active.clear()
            pending = null
            _speaking.value = false
        }
    }

    override fun shutdown() {
        engine?.stop()
        engine?.shutdown()
        engine = null
    }
}
