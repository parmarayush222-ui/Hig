package com.bot.tts

import kotlinx.coroutines.flow.StateFlow

data class VoiceParams(
    val rate: Float = 1.0f,
    val pitch: Float = 1.0f,
    /** Exact voice name from [VoiceInfo.name]; null means "automatic". */
    val voiceName: String? = null,
    /** BCP-47 tag used only when [voiceName] is null; blank means the device language. */
    val languageTag: String = "",
)

data class VoiceInfo(
    val name: String,
    val languageTag: String,
    val displayLanguage: String,
    /** True only if the engine says this voice needs no network connection. */
    val offline: Boolean,
    val quality: Int,
)

sealed interface TtsStatus {
    data object Initializing : TtsStatus
    data object Ready : TtsStatus
    data class Unavailable(val reason: String) : TtsStatus
}

interface TtsEngine {
    val status: StateFlow<TtsStatus>
    val isSpeaking: StateFlow<Boolean>
    val voices: StateFlow<List<VoiceInfo>>

    /** A short, user-readable problem from the last speak attempt, or null. */
    val notice: StateFlow<String?>

    /** Interrupts any current speech and speaks [text]. */
    fun speak(text: String, params: VoiceParams)

    fun stop()
    fun shutdown()
}
