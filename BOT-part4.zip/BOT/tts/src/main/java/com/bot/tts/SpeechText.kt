package com.bot.tts

private val CODE_BLOCK = Regex("```[\\s\\S]*?```")
private val MD_LINK = Regex("\\[([^\\]]+)]\\([^)]*\\)")
private val URL = Regex("https?://\\S+")
private val HEADING = Regex("(?m)^\\s{0,3}#{1,6}\\s*")
private val BULLET = Regex("(?m)^\\s*[-*\u2022]\\s+")
private val EMPHASIS = Regex("[*`~]+")
private val EDGE_UNDERSCORE = Regex("(?<![A-Za-z0-9])_+|_+(?![A-Za-z0-9])")
private val SPACES = Regex("[ \\t]+")
private val BLANK_LINES = Regex("\\n{3,}")

/** Removes markdown noise so the voice doesn't read out symbols, code or long URLs. */
fun cleanForSpeech(raw: String): String {
    var s = raw
    s = CODE_BLOCK.replace(s, " (code omitted) ")
    s = MD_LINK.replace(s, "\$1")
    s = URL.replace(s, "link")
    s = HEADING.replace(s, "")
    s = BULLET.replace(s, "")
    s = EMPHASIS.replace(s, "")
    s = EDGE_UNDERSCORE.replace(s, "")
    s = SPACES.replace(s, " ")
    s = BLANK_LINES.replace(s, "\n\n")
    return s.trim()
}

/**
 * Splits text into chunks of at most [maxLen] characters (engines reject very long input),
 * preferring sentence ends, then spaces, then a hard cut.
 */
fun splitForSpeech(text: String, maxLen: Int = 3500): List<String> {
    require(maxLen >= 50) { "maxLen too small" }
    val out = mutableListOf<String>()
    var rest = text.trim()
    while (rest.isNotEmpty()) {
        if (rest.length <= maxLen) {
            out += rest
            break
        }
        val window = rest.substring(0, maxLen)
        var cut = maxOf(
            window.lastIndexOf(". "),
            window.lastIndexOf("! "),
            window.lastIndexOf("? "),
            window.lastIndexOf('\n'),
        )
        if (cut < maxLen / 2) cut = window.lastIndexOf(' ')
        val end = if (cut <= 0) maxLen else cut + 1
        out += rest.substring(0, end).trim()
        rest = rest.substring(end).trim()
    }
    return out.filter { it.isNotEmpty() }
}
