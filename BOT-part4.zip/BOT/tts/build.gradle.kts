plugins {
    alias(libs.plugins.android.library)
}

android {
    namespace = "com.bot.tts"
    compileSdk = 36

    defaultConfig {
        minSdk = 26
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    api(libs.coroutines.android)

    testImplementation(libs.junit)
}
