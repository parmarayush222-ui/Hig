package com.bot.ai

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.bot.memory.db.ConversationDao
import com.bot.memory.db.ConversationEntity
import com.bot.memory.db.MessageDao
import com.bot.memory.db.MessageEntity
import com.bot.memory.settings.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import java.io.File

class FakeConversationDao : ConversationDao {
    val rows = MutableStateFlow<List<ConversationEntity>>(emptyList())
    private var nextId = 1L
    override suspend fun insert(conversation: ConversationEntity): Long {
        val id = nextId++
        rows.value = rows.value + conversation.copy(id = id)
        return id
    }
    private fun change(id: Long, f: (ConversationEntity) -> ConversationEntity) {
        rows.value = rows.value.map { if (it.id == id) f(it) else it }
    }
    override suspend fun touch(id: Long, time: Long) = change(id) { it.copy(updatedAt = time) }
    override suspend fun rename(id: Long, title: String) = change(id) { it.copy(title = title) }
    override suspend fun renameIfTitle(id: Long, defaultTitle: String, title: String) =
        change(id) { if (it.title == defaultTitle) it.copy(title = title) else it }
    override fun observeAll(): Flow<List<ConversationEntity>> = rows
    override suspend fun latestId(): Long? = rows.value.maxByOrNull { it.updatedAt }?.id
    override suspend fun delete(id: Long) { rows.value = rows.value.filterNot { it.id == id } }
    override suspend fun deleteAll() { rows.value = emptyList() }
}

class FakeMessageDao : MessageDao {
    val rows = MutableStateFlow<List<MessageEntity>>(emptyList())
    private var nextId = 1L
    override suspend fun insert(message: MessageEntity): Long {
        val id = nextId++
        rows.value = rows.value + message.copy(id = id)
        return id
    }
    override suspend fun updateContent(id: Long, content: String, status: String) {
        rows.value = rows.value.map { if (it.id == id) it.copy(content = content, status = status) else it }
    }
    override fun observeForConversation(conversationId: Long): Flow<List<MessageEntity>> =
        rows.map { list -> list.filter { it.conversationId == conversationId } }
    override suspend fun recent(conversationId: Long, limit: Int): List<MessageEntity> =
        rows.value.filter { it.conversationId == conversationId }.sortedByDescending { it.id }.take(limit)
    override suspend fun search(escapedQuery: String, limit: Int): List<MessageEntity> = emptyList()
    override fun observeCount(): Flow<Int> = rows.map { it.size }
    override suspend fun failPending() {
        rows.value = rows.value.map {
            if (it.status == "pending") it.copy(status = "error", content = it.content.ifEmpty { "(Interrupted)" }) else it
        }
    }
    override suspend fun deleteAll() { rows.value = emptyList() }
}

/** A real DataStore backed by a temp file, so SettingsRepository is tested unmodified. */
fun testSettings(dir: File): SettingsRepository = SettingsRepository(
    PreferenceDataStoreFactory.create(
        scope = CoroutineScope(Dispatchers.IO + Job()),
        produceFile = { File(dir, "test.preferences_pb") },
    ),
)
