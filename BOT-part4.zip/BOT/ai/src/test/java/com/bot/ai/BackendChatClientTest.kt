package com.bot.ai

import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class BackendChatClientTest {

    private fun clientReturning(code: Int, body: String, onRequest: (Request) -> Unit = {}): BackendChatClient {
        val http = OkHttpClient.Builder().addInterceptor(Interceptor { chain ->
            onRequest(chain.request())
            Response.Builder()
                .request(chain.request())
                .protocol(Protocol.HTTP_1_1)
                .code(code)
                .message("test")
                .body(body.toResponseBody("text/event-stream".toMediaType()))
                .build()
        }).build()
        return BackendChatClient(http)
    }

    private val request = ChatRequest(
        backendUrl = "https://bot.example.com/",
        token = "tok",
        model = "gemini-3.5-flash",
        systemPrompt = "be brief",
        turns = listOf(ChatTurn(TurnRole.USER, "hi")),
    )

    private fun events(client: BackendChatClient, req: ChatRequest = request): List<ChatEvent> =
        runBlocking { client.stream(req).toList() }

    @Test
    fun streamsDeltasThenDone() {
        val body = "data: {\"text\":\"Hel\"}\n\ndata: {\"text\":\"lo\"}\n\ndata: {\"done\":true}\n\n"
        assertEquals(
            listOf(ChatEvent.Delta("Hel"), ChatEvent.Delta("lo"), ChatEvent.Done),
            events(clientReturning(200, body)),
        )
    }

    @Test
    fun sendsExpectedRequest() {
        var seen: Request? = null
        events(clientReturning(200, "data: {\"done\":true}\n\n") { seen = it })
        val r = seen!!
        assertEquals("https://bot.example.com/v1/chat/stream", r.url.toString())
        assertEquals("Bearer tok", r.header("Authorization"))
        assertEquals("POST", r.method)
        val sent = okio.Buffer().also { r.body!!.writeTo(it) }.readUtf8()
        assertTrue(sent.contains("\"model\":\"gemini-3.5-flash\""))
        assertTrue(sent.contains("\"role\":\"user\""))
        assertTrue(sent.contains("\"systemPrompt\":\"be brief\""))
    }

    @Test
    fun unauthorizedAndRateLimitedAreMapped() {
        val a = events(clientReturning(401, """{"error":{"code":"unauthorized","message":"no"}}"""))
        assertEquals(listOf<ChatEvent>(ChatEvent.Failure(AiError.Unauthorized)), a)
        val r = events(clientReturning(429, """{"error":{"code":"rate_limited","message":"slow"}}"""))
        assertTrue((r.single() as ChatEvent.Failure).error is AiError.RateLimited)
    }

    @Test
    fun truncatedStreamIsAFailure() {
        val out = events(clientReturning(200, "data: {\"text\":\"partial\"}\n\n"))
        assertEquals(ChatEvent.Delta("partial"), out[0])
        assertTrue((out[1] as ChatEvent.Failure).error is AiError.Network)
    }

    @Test
    fun errorEventInStreamStopsIt() {
        val body = "data: {\"text\":\"a\"}\n\ndata: {\"error\":{\"code\":\"timeout\",\"message\":\"t\"}}\n\ndata: {\"text\":\"ignored\"}\n\n"
        val out = events(clientReturning(200, body))
        assertEquals(listOf<ChatEvent>(ChatEvent.Delta("a"), ChatEvent.Failure(AiError.Timeout)), out)
    }

    @Test
    fun networkFailureIsReported() {
        val http = OkHttpClient.Builder().addInterceptor(Interceptor { throw IOException("no route") }).build()
        val out = events(BackendChatClient(http))
        assertTrue((out.single() as ChatEvent.Failure).error is AiError.Network)
    }

    @Test
    fun missingConfigFailsWithoutNetwork() {
        val client = clientReturning(500, "should not be called")
        val noUrl = events(client, request.copy(backendUrl = ""))
        assertTrue((noUrl.single() as ChatEvent.Failure).error is AiError.NotConfigured)
        val noToken = events(client, request.copy(token = " "))
        assertTrue((noToken.single() as ChatEvent.Failure).error is AiError.NotConfigured)
        val badUrl = events(client, request.copy(backendUrl = "not a url"))
        assertTrue((badUrl.single() as ChatEvent.Failure).error is AiError.NotConfigured)
    }
}
