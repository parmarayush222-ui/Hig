package com.bot.ai

import com.bot.memory.db.MessageEntity
import com.bot.memory.db.MessageStatus
import com.bot.memory.db.Role
import com.bot.memory.repo.ChatRepository
import com.bot.memory.settings.Personality
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class ChatOrchestratorTest {
    @get:Rule val tmp = TemporaryFolder()

    private class Env(val tmp: TemporaryFolder, client: ChatClient) {
        val conversations = FakeConversationDao()
        val messages = FakeMessageDao()
        val chat = ChatRepository(conversations, messages) { 1_000L }
        val settings = testSettings(tmp.newFolder())
        val orchestrator = ChatOrchestrator(chat, settings, client, writeIntervalMs = 0) { 1_000L }
    }

    private fun reply(env: Env) = env.messages.rows.value.last()

    @Test
    fun successfulReplyIsSavedAndRequestIsBuilt() = runBlocking {
        var captured: ChatRequest? = null
        val env = Env(tmp) { req ->
            captured = req
            flowOf(ChatEvent.Delta("Hel"), ChatEvent.Delta("lo"), ChatEvent.Done)
        }
        env.settings.setBackendUrl("https://bot.example.com")
        env.settings.setBackendToken("tok")
        env.settings.setPersonality(Personality.MENTOR)
        val id = env.chat.createConversation()

        val result = env.orchestrator.send(id, "What is Kotlin?")

        assertEquals("Hello", result)
        assertEquals("Hello", reply(env).content)
        assertEquals(MessageStatus.OK, reply(env).status)
        assertEquals(Role.MODEL, reply(env).role)
        assertEquals(BotPhase.IDLE, env.orchestrator.phase.value)
        assertEquals("What is Kotlin?", env.conversations.rows.value.single().title)
        val req = captured!!
        assertEquals("https://bot.example.com", req.backendUrl)
        assertEquals("tok", req.token)
        assertEquals("gemini-3.5-flash", req.model)
        assertEquals(Personality.MENTOR.systemPrompt, req.systemPrompt)
        assertEquals(listOf(ChatTurn(TurnRole.USER, "What is Kotlin?")), req.turns)
    }

    @Test
    fun failureWithNoTextShowsFriendlyError() = runBlocking {
        val env = Env(tmp) { flowOf(ChatEvent.Failure(AiError.Unauthorized)) }
        val id = env.chat.createConversation()
        val result = env.orchestrator.send(id, "hi")
        assertEquals(null, result)
        assertEquals(MessageStatus.ERROR, reply(env).status)
        assertEquals(AiError.Unauthorized.userMessage, reply(env).content)
    }

    @Test
    fun failureAfterPartialTextKeepsThePartial() = runBlocking {
        val env = Env(tmp) { flowOf(ChatEvent.Delta("Half"), ChatEvent.Failure(AiError.Timeout)) }
        val id = env.chat.createConversation()
        env.orchestrator.send(id, "hi")
        assertEquals(MessageStatus.ERROR, reply(env).status)
        assertTrue(reply(env).content.startsWith("Half"))
        assertTrue(reply(env).content.contains(AiError.Timeout.userMessage))
    }

    @Test
    fun emptyReplyIsMarkedAsError() = runBlocking {
        val env = Env(tmp) { flowOf(ChatEvent.Done) }
        val id = env.chat.createConversation()
        env.orchestrator.send(id, "hi")
        assertEquals(MessageStatus.ERROR, reply(env).status)
    }

    @Test
    fun cancellingKeepsPartialTextAsOk() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val env = Env(tmp) {
            flow<ChatEvent> {
                emit(ChatEvent.Delta("par"))
                started.complete(Unit)
                awaitCancellation()
            }
        }
        val id = env.chat.createConversation()
        val job = launch { env.orchestrator.send(id, "hi") }
        started.await()
        job.cancelAndJoin()
        assertEquals("par", reply(env).content)
        assertEquals(MessageStatus.OK, reply(env).status)
        assertEquals(BotPhase.IDLE, env.orchestrator.phase.value)
    }

    @Test
    fun cancellingBeforeAnyTextMarksStopped() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val env = Env(tmp) {
            flow<ChatEvent> { started.complete(Unit); awaitCancellation() }
        }
        val id = env.chat.createConversation()
        val job = launch { env.orchestrator.send(id, "hi") }
        started.await()
        job.cancelAndJoin()
        assertEquals("(Stopped)", reply(env).content)
        assertEquals(MessageStatus.ERROR, reply(env).status)
    }

    @Test
    fun unexpectedExceptionBecomesUnknownError() = runBlocking {
        val env = Env(tmp) { _: ChatRequest -> flow<ChatEvent> { error("boom") } }
        val id = env.chat.createConversation()
        env.orchestrator.send(id, "hi")
        assertEquals(MessageStatus.ERROR, reply(env).status)
        assertTrue(reply(env).content.contains("boom"))
    }

    // ---- buildContext ----

    private fun msg(role: String, text: String, status: String = MessageStatus.OK) =
        MessageEntity(conversationId = 1, role = role, content = text, createdAt = 0, status = status)

    @Test
    fun contextSkipsFailedPendingBlankAndSystemRows() {
        val ctx = buildContext(
            listOf(
                msg(Role.SYSTEM, "sys"),
                msg(Role.USER, "q1"),
                msg(Role.MODEL, "boom", MessageStatus.ERROR),
                msg(Role.MODEL, "", MessageStatus.PENDING),
                msg(Role.MODEL, "   "),
                msg(Role.USER, "q2"),
            ),
        )
        assertEquals(listOf(ChatTurn(TurnRole.USER, "q1\n\nq2")), ctx)
    }

    @Test
    fun contextStartsWithUserAndKeepsAlternation() {
        val ctx = buildContext(
            listOf(
                msg(Role.MODEL, "orphan"),
                msg(Role.USER, "a"),
                msg(Role.MODEL, "b"),
                msg(Role.USER, "c"),
            ),
        )
        assertEquals(
            listOf(ChatTurn(TurnRole.USER, "a"), ChatTurn(TurnRole.MODEL, "b"), ChatTurn(TurnRole.USER, "c")),
            ctx,
        )
    }
}
