package com.bot.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolTest {
    @Test
    fun parsesTextDoneAndErrors() {
        assertEquals(ChatEvent.Delta("hi"), parseSseLine("""data: {"text":"hi"}"""))
        assertEquals(ChatEvent.Done, parseSseLine("""data: {"done":true}"""))
        val rate = parseSseLine("""data: {"error":{"code":"rate_limited","message":"slow"}}""")
        assertTrue((rate as ChatEvent.Failure).error is AiError.RateLimited)
        val blocked = parseSseLine("""data: {"error":{"code":"blocked","message":"x"}}""")
        assertTrue((blocked as ChatEvent.Failure).error is AiError.Blocked)
    }

    @Test
    fun ignoresJunk() {
        assertNull(parseSseLine(""))
        assertNull(parseSseLine(": keep-alive"))
        assertNull(parseSseLine("data: not json"))
        assertNull(parseSseLine("""data: {"text":""}"""))
        assertNull(parseSseLine("""data: {"other":1}"""))
    }

    @Test
    fun httpErrorsPreferProxyCodes() {
        assertEquals(AiError.Unauthorized, errorFromHttp(401, """{"error":{"code":"unauthorized","message":"x"}}"""))
        assertTrue(errorFromHttp(429, "") is AiError.RateLimited)
        assertEquals(AiError.Timeout, errorFromHttp(504, "<html>gateway</html>"))
        val upstream = errorFromHttp(502, """{"error":{"code":"upstream_auth","message":"key"}}""")
        assertTrue(upstream is AiError.Server && upstream.code == "upstream_auth")
        assertTrue(errorFromHttp(503, """{"error":{"code":"not_configured","message":"k"}}""") is AiError.NotConfigured)
    }
}
