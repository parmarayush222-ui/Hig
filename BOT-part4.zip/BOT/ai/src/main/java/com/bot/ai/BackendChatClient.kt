package com.bot.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

fun defaultHttpClient(): OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS) // max silence between streamed lines
    .callTimeout(0, TimeUnit.SECONDS)
    .build()

private val JSON_MEDIA = "application/json".toMediaType()

/** Talks to the BOT backend proxy; the Gemini key never reaches the phone. */
class BackendChatClient(private val http: OkHttpClient = defaultHttpClient()) : ChatClient {

    override fun stream(request: ChatRequest): Flow<ChatEvent> = flow {
        if (request.backendUrl.isBlank()) {
            emit(ChatEvent.Failure(AiError.NotConfigured("Open Settings and enter your backend URL.")))
            return@flow
        }
        if (request.token.isBlank()) {
            emit(ChatEvent.Failure(AiError.NotConfigured("Open Settings and enter your app token.")))
            return@flow
        }
        val body = ProtocolJson.encodeToString(
            ProxyRequest.serializer(),
            ProxyRequest(
                model = request.model,
                systemPrompt = request.systemPrompt,
                messages = request.turns.map { ProxyMessage(it.role.wire, it.text) },
            ),
        ).toRequestBody(JSON_MEDIA)

        val httpRequest = try {
            Request.Builder()
                .url(request.backendUrl.trimEnd('/') + "/v1/chat/stream")
                .header("Authorization", "Bearer ${request.token}")
                .header("Accept", "text/event-stream")
                .post(body)
                .build()
        } catch (e: IllegalArgumentException) {
            emit(ChatEvent.Failure(AiError.NotConfigured("The backend URL looks invalid.")))
            return@flow
        }

        val call = http.newCall(httpRequest)
        val handle = currentCoroutineContext()[Job]?.invokeOnCompletion { call.cancel() }
        try {
            call.execute().use { response ->
                if (!response.isSuccessful) {
                    emit(ChatEvent.Failure(errorFromHttp(response.code, response.body.string())))
                    return@flow
                }
                val source = response.body.source()
                var finished = false
                while (!finished) {
                    val line = source.readUtf8Line() ?: break
                    val event = parseSseLine(line) ?: continue
                    emit(event)
                    if (event is ChatEvent.Done || event is ChatEvent.Failure) finished = true
                }
                if (!finished) {
                    emit(ChatEvent.Failure(AiError.Network("the connection closed before the reply finished")))
                }
            }
        } catch (e: SocketTimeoutException) {
            currentCoroutineContext().ensureActive()
            emit(ChatEvent.Failure(AiError.Timeout))
        } catch (e: IOException) {
            currentCoroutineContext().ensureActive() // cancelled calls surface as IOException
            emit(ChatEvent.Failure(AiError.Network(e.message ?: e.javaClass.simpleName)))
        } finally {
            handle?.dispose()
        }
    }.flowOn(Dispatchers.IO)
}

/** Calls GET /v1/status to confirm the URL, the token and whether the server has a Gemini key. */
class ConnectionChecker(private val http: OkHttpClient = defaultHttpClient()) {

    suspend fun check(backendUrl: String, token: String): ConnectionStatus = withContext(Dispatchers.IO) {
        if (backendUrl.isBlank()) {
            return@withContext ConnectionStatus.Failed(AiError.NotConfigured("Enter your backend URL."))
        }
        if (token.isBlank()) {
            return@withContext ConnectionStatus.Failed(AiError.NotConfigured("Enter your app token."))
        }
        val request = try {
            Request.Builder()
                .url(backendUrl.trimEnd('/') + "/v1/status")
                .header("Authorization", "Bearer $token")
                .build()
        } catch (e: IllegalArgumentException) {
            return@withContext ConnectionStatus.Failed(AiError.NotConfigured("The backend URL looks invalid."))
        }
        try {
            http.newCall(request).execute().use { response ->
                val text = response.body.string()
                if (!response.isSuccessful) {
                    return@use ConnectionStatus.Failed(errorFromHttp(response.code, text))
                }
                val status = ProtocolJson.decodeFromString(ProxyStatus.serializer(), text)
                ConnectionStatus.Connected(status.geminiConfigured, status.models)
            }
        } catch (e: SocketTimeoutException) {
            ConnectionStatus.Failed(AiError.Timeout)
        } catch (e: IOException) {
            ConnectionStatus.Failed(AiError.Network(e.message ?: e.javaClass.simpleName))
        } catch (e: kotlinx.serialization.SerializationException) {
            ConnectionStatus.Failed(AiError.Unknown("the server's reply wasn't understood. Is this the BOT backend URL?"))
        }
    }
}
