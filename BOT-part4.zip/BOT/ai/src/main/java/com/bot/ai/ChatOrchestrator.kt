package com.bot.ai

import com.bot.memory.db.MessageEntity
import com.bot.memory.db.MessageStatus
import com.bot.memory.db.Role
import com.bot.memory.repo.ChatRepository
import com.bot.memory.settings.SettingsRepository
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlin.coroutines.cancellation.CancellationException

enum class BotPhase { IDLE, THINKING, STREAMING }

/**
 * Turns a user message into a saved, streamed model reply.
 * The UI observes the database, so streaming text appears as the reply row is updated.
 */
class ChatOrchestrator(
    private val chat: ChatRepository,
    private val settings: SettingsRepository,
    private val client: ChatClient,
    private val contextLimit: Int = 20,
    private val writeIntervalMs: Long = 200,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val _phase = MutableStateFlow(BotPhase.IDLE)
    val phase: StateFlow<BotPhase> = _phase.asStateFlow()

    /**
     * Runs until the reply is complete, failed or cancelled. Cancelling keeps the partial text.
     * Returns the finished reply text, or null if the reply failed or was empty.
     */
    suspend fun send(conversationId: Long, userText: String): String? {
        val s = settings.settings.first()
        chat.addMessage(conversationId, Role.USER, userText)
        chat.autoTitle(conversationId, userText)
        val turns = buildContext(chat.recentMessages(conversationId, contextLimit))
        val replyId = chat.addMessage(conversationId, Role.MODEL, "", MessageStatus.PENDING)

        val request = ChatRequest(
            backendUrl = s.backendUrl,
            token = s.backendToken,
            model = s.modelName,
            systemPrompt = s.personality.systemPrompt,
            turns = turns,
        )

        val text = StringBuilder()
        var failure: AiError? = null
        var lastWrite = 0L
        _phase.value = BotPhase.THINKING
        try {
            client.stream(request).collect { event ->
                when (event) {
                    is ChatEvent.Delta -> {
                        text.append(event.text)
                        _phase.value = BotPhase.STREAMING
                        val now = clock()
                        if (now - lastWrite >= writeIntervalMs) {
                            chat.updateMessage(replyId, text.toString(), MessageStatus.PENDING)
                            lastWrite = now
                        }
                    }
                    ChatEvent.Done -> Unit
                    is ChatEvent.Failure -> failure = event.error
                }
            }
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                if (text.isEmpty()) chat.updateMessage(replyId, "(Stopped)", MessageStatus.ERROR)
                else chat.updateMessage(replyId, text.toString(), MessageStatus.OK)
            }
            throw e
        } catch (e: Exception) {
            failure = AiError.Unknown(e.message ?: e.javaClass.simpleName)
        } finally {
            _phase.value = BotPhase.IDLE
        }

        val error = failure
        return when {
            error != null && text.isEmpty() -> {
                chat.updateMessage(replyId, error.userMessage, MessageStatus.ERROR)
                null
            }
            error != null -> {
                chat.updateMessage(replyId, "$text\n\n[Interrupted: ${error.userMessage}]", MessageStatus.ERROR)
                null
            }
            text.isEmpty() -> {
                chat.updateMessage(replyId, "(No response)", MessageStatus.ERROR)
                null
            }
            else -> {
                chat.updateMessage(replyId, text.toString(), MessageStatus.OK)
                text.toString()
            }
        }
    }
}

/**
 * Builds the model context from stored messages (oldest first):
 * drops system, pending, failed and blank rows, merges consecutive same-role turns,
 * and removes leading model turns so the conversation starts with the user.
 */
fun buildContext(stored: List<MessageEntity>): List<ChatTurn> {
    val merged = mutableListOf<ChatTurn>()
    for (m in stored) {
        if (m.status != MessageStatus.OK || m.content.isBlank()) continue
        val role = when (m.role) {
            Role.USER -> TurnRole.USER
            Role.MODEL -> TurnRole.MODEL
            else -> continue
        }
        val last = merged.lastOrNull()
        if (last != null && last.role == role) {
            merged[merged.size - 1] = last.copy(text = last.text + "\n\n" + m.content)
        } else {
            merged += ChatTurn(role, m.content)
        }
    }
    return merged.dropWhile { it.role == TurnRole.MODEL }
}
