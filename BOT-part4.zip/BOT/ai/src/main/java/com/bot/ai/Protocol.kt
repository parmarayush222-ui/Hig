package com.bot.ai

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

internal val ProtocolJson = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
}

@Serializable
internal data class ProxyMessage(val role: String, val text: String)

@Serializable
internal data class ProxyRequest(
    val model: String,
    val systemPrompt: String,
    val messages: List<ProxyMessage>,
)

@Serializable
internal data class ProxyError(val code: String? = null, val message: String? = null)

/** One SSE event or one error body from the proxy. */
@Serializable
internal data class ProxyEvent(
    val text: String? = null,
    val done: Boolean? = null,
    val error: ProxyError? = null,
)

@Serializable
internal data class ProxyStatus(
    val ok: Boolean = false,
    val geminiConfigured: Boolean = false,
    val models: List<String> = emptyList(),
)

/** Parses one SSE line from the proxy. Returns null for blank lines, comments and junk. */
internal fun parseSseLine(line: String): ChatEvent? {
    if (!line.startsWith("data:")) return null
    val payload = line.removePrefix("data:").trim()
    if (payload.isEmpty()) return null
    val event = try {
        ProtocolJson.decodeFromString(ProxyEvent.serializer(), payload)
    } catch (e: Exception) {
        return null
    }
    return when {
        event.error != null -> ChatEvent.Failure(AiError.fromProxy(event.error.code, event.error.message))
        event.done == true -> ChatEvent.Done
        !event.text.isNullOrEmpty() -> ChatEvent.Delta(event.text)
        else -> null
    }
}

/** Turns a non-2xx proxy response into an error, preferring the proxy's own error code. */
internal fun errorFromHttp(status: Int, body: String): AiError {
    val parsed = try {
        ProtocolJson.decodeFromString(ProxyEvent.serializer(), body).error
    } catch (e: Exception) {
        null
    }
    return AiError.fromProxy(parsed?.code, parsed?.message ?: body.take(200), status)
}
