package com.bot.ai

import kotlinx.coroutines.flow.Flow

enum class TurnRole(val wire: String) { USER("user"), MODEL("model") }

data class ChatTurn(val role: TurnRole, val text: String)

data class ChatRequest(
    val backendUrl: String,
    val token: String,
    val model: String,
    val systemPrompt: String,
    val turns: List<ChatTurn>,
)

sealed interface ChatEvent {
    data class Delta(val text: String) : ChatEvent
    data object Done : ChatEvent
    data class Failure(val error: AiError) : ChatEvent
}

/** Everything that can go wrong, each with text that is safe to show the user. */
sealed class AiError(val userMessage: String) {
    data class NotConfigured(val detail: String) : AiError("BOT isn't connected yet. $detail")
    data object Unauthorized : AiError("The backend rejected the app token. Check the token in Settings.")
    data class RateLimited(val detail: String) : AiError("Too many requests right now. Wait a moment and try again. ($detail)")
    data object Timeout : AiError("The AI took too long to answer. Try again.")
    data class Network(val detail: String) : AiError("Can't reach the backend. Check your internet connection. ($detail)")
    data class Blocked(val detail: String) : AiError("Gemini declined to answer that. $detail")
    data class Server(val code: String, val detail: String) : AiError("The backend reported a problem ($code): $detail")
    data class Unknown(val detail: String) : AiError("Something went wrong: $detail")

    companion object {
        /** Maps a stable proxy error code (or, failing that, the HTTP status) to an error. */
        fun fromProxy(code: String?, message: String?, httpStatus: Int? = null): AiError {
            val msg = message?.takeIf { it.isNotBlank() } ?: "no details"
            return when {
                code == "unauthorized" || (code == null && httpStatus == 401) -> Unauthorized
                code == "rate_limited" || (code == null && httpStatus == 429) -> RateLimited(msg)
                code == "timeout" || (code == null && (httpStatus == 408 || httpStatus == 504)) -> Timeout
                code == "blocked" -> Blocked(msg)
                code == "not_configured" -> NotConfigured("The server has no Gemini key set up.")
                else -> Server(code ?: "http_${httpStatus ?: "?"}", msg)
            }
        }
    }
}

fun interface ChatClient {
    fun stream(request: ChatRequest): Flow<ChatEvent>
}

sealed interface ConnectionStatus {
    data object Checking : ConnectionStatus
    data class Connected(val geminiConfigured: Boolean, val models: List<String>) : ConnectionStatus
    data class Failed(val error: AiError) : ConnectionStatus
}
