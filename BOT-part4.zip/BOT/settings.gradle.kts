pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "BOT"
include(":app")
include(":memory")
include(":ai")
include(":tts")
// More modules (wake word, screen, actions, scheduler, ...) arrive in later milestones.
