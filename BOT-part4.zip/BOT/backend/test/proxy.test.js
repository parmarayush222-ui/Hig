'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { createServer } = require('../server');
const lib = require('../lib');

function listen(server) {
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server.address().port)));
}

/** Fake Gemini upstream. mode: 'ok' | 'thought' | 'rate' | 'authfail' | 'blocked' */
function fakeGemini(mode, seen) {
  return http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      seen.push({ url: req.url, key: req.headers['x-goog-api-key'], body: JSON.parse(body) });
      if (mode === 'rate') { res.writeHead(429); return res.end(JSON.stringify({ error: { message: 'quota' } })); }
      if (mode === 'authfail') { res.writeHead(403); return res.end('{}'); }
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      const ev = (parts, extra = {}) => `data: ${JSON.stringify({ candidates: [{ content: { parts }, ...extra }] })}\r\n\r\n`;
      if (mode === 'blocked') {
        return res.end(`data: ${JSON.stringify({ promptFeedback: { blockReason: 'SAFETY' } })}\n\n`);
      }
      const first = ev([{ text: 'Hel' }]);
      const second = ev([{ text: 'secret thinking', thought: true }, { text: 'lo' }]);
      // Split the second event mid-line to exercise the incremental parser.
      res.write(first);
      res.write(second.slice(0, 20));
      setTimeout(() => { res.write(second.slice(20)); res.end(); }, 20);
    });
  });
}

async function setup(mode, cfgOverrides = {}) {
  const seen = [];
  const upstream = fakeGemini(mode, seen);
  const upPort = await listen(upstream);
  const cfg = {
    ...lib.loadConfig({ GEMINI_API_KEY: 'k', BOT_APP_TOKEN: 'tok', ALLOWED_MODELS: 'm1,m2' }),
    geminiBase: `http://127.0.0.1:${upPort}/v1beta`,
    ...cfgOverrides,
  };
  const proxy = createServer(cfg);
  const port = await listen(proxy);
  const close = () => { proxy.close(); upstream.close(); proxy.closeAllConnections?.(); upstream.closeAllConnections?.(); };
  return { base: `http://127.0.0.1:${port}`, seen, close };
}

const auth = { authorization: 'Bearer tok', 'content-type': 'application/json' };
const goodBody = { model: 'm1', systemPrompt: 'be brief', messages: [{ role: 'user', text: 'hi' }] };

async function events(res) {
  const text = await res.text();
  return text.split('\n\n').filter(Boolean).map((b) => JSON.parse(b.replace(/^data: /, '')));
}

test('health is public, status needs token', async () => {
  const s = await setup('ok');
  try {
    assert.equal((await fetch(`${s.base}/health`)).status, 200);
    assert.equal((await fetch(`${s.base}/v1/status`)).status, 401);
    const ok = await fetch(`${s.base}/v1/status`, { headers: auth });
    assert.deepEqual(await ok.json(), { ok: true, geminiConfigured: true, models: ['m1', 'm2'] });
  } finally { s.close(); }
});

test('wrong token is rejected', async () => {
  const s = await setup('ok');
  try {
    const r = await fetch(`${s.base}/v1/chat/stream`, { method: 'POST', headers: { ...auth, authorization: 'Bearer nope' }, body: JSON.stringify(goodBody) });
    assert.equal(r.status, 401);
    assert.equal((await r.json()).error.code, 'unauthorized');
  } finally { s.close(); }
});

test('rejects disallowed model and bad shapes', async () => {
  const s = await setup('ok');
  try {
    for (const body of [
      { ...goodBody, model: 'evil' },
      { ...goodBody, messages: [] },
      { ...goodBody, messages: [{ role: 'model', text: 'x' }] },
      { ...goodBody, messages: [{ role: 'admin', text: 'x' }] },
    ]) {
      const r = await fetch(`${s.base}/v1/chat/stream`, { method: 'POST', headers: auth, body: JSON.stringify(body) });
      assert.equal(r.status, 400);
    }
    const r = await fetch(`${s.base}/v1/chat/stream`, { method: 'POST', headers: auth, body: '{not json' });
    assert.equal(r.status, 400);
  } finally { s.close(); }
});

test('streams text, filters thoughts, sends key upstream only', async () => {
  const s = await setup('ok');
  try {
    const r = await fetch(`${s.base}/v1/chat/stream`, { method: 'POST', headers: auth, body: JSON.stringify(goodBody) });
    assert.equal(r.status, 200);
    const evs = await events(r);
    assert.deepEqual(evs, [{ text: 'Hel' }, { text: 'lo' }, { done: true }]);
    assert.equal(s.seen.length, 1);
    assert.equal(s.seen[0].key, 'k');
    assert.match(s.seen[0].url, /models\/m1:streamGenerateContent\?alt=sse$/);
    assert.deepEqual(s.seen[0].body.systemInstruction, { parts: [{ text: 'be brief' }] });
    assert.deepEqual(s.seen[0].body.contents, [{ role: 'user', parts: [{ text: 'hi' }] }]);
  } finally { s.close(); }
});

test('maps upstream rate limit and key errors', async () => {
  for (const [mode, status, code] of [['rate', 429, 'rate_limited'], ['authfail', 502, 'upstream_auth']]) {
    const s = await setup(mode);
    try {
      const r = await fetch(`${s.base}/v1/chat/stream`, { method: 'POST', headers: auth, body: JSON.stringify(goodBody) });
      assert.equal(r.status, status);
      assert.equal((await r.json()).error.code, code);
    } finally { s.close(); }
  }
});

test('blocked prompt becomes a blocked error event', async () => {
  const s = await setup('blocked');
  try {
    const r = await fetch(`${s.base}/v1/chat/stream`, { method: 'POST', headers: auth, body: JSON.stringify(goodBody) });
    const evs = await events(r);
    assert.equal(evs.length, 1);
    assert.equal(evs[0].error.code, 'blocked');
  } finally { s.close(); }
});

test('per-IP rate limit trips', async () => {
  const s = await setup('ok', { rateLimitPerMin: 2 });
  try {
    const codes = [];
    for (let i = 0; i < 3; i++) {
      const r = await fetch(`${s.base}/v1/chat/stream`, { method: 'POST', headers: auth, body: JSON.stringify(goodBody) });
      codes.push(r.status);
      await r.text();
    }
    assert.deepEqual(codes, [200, 200, 429]);
  } finally { s.close(); }
});

test('missing gemini key gives not_configured', async () => {
  const s = await setup('ok', { apiKey: '' });
  try {
    const r = await fetch(`${s.base}/v1/chat/stream`, { method: 'POST', headers: auth, body: JSON.stringify(goodBody) });
    assert.equal(r.status, 503);
    assert.equal((await r.json()).error.code, 'not_configured');
  } finally { s.close(); }
});

test('sse parser handles splits and ignores junk', () => {
  const got = [];
  const p = lib.createSseParser((o) => got.push(o));
  p.feed('data: {"a"'); p.feed(':1}\n\nevent: x\n: comment\ndata: nope\ndata: {"b":2}');
  p.end();
  assert.deepEqual(got, [{ a: 1 }, { b: 2 }]);
});
