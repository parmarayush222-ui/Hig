'use strict';

const MAX_MESSAGES = 40;
const MAX_TOTAL_CHARS = 60000;
const MAX_SYSTEM_CHARS = 4000;

function loadConfig(env) {
  return {
    port: Number(env.PORT) || 8080,
    apiKey: env.GEMINI_API_KEY && env.GEMINI_API_KEY !== 'replace-me' ? env.GEMINI_API_KEY : '',
    appToken: env.BOT_APP_TOKEN && env.BOT_APP_TOKEN !== 'replace-me' ? env.BOT_APP_TOKEN : '',
    allowedModels: (env.ALLOWED_MODELS || 'gemini-3.5-flash,gemini-3.5-flash-lite')
      .split(',').map((s) => s.trim()).filter(Boolean),
    rateLimitPerMin: Number(env.RATE_LIMIT_PER_MIN) || 30,
    trustProxy: env.TRUST_PROXY === '1',
    upstreamTimeoutMs: Number(env.UPSTREAM_TIMEOUT_MS) || 90000,
    geminiBase: env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta',
  };
}

function validateChatBody(body, allowedModels) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return { error: 'Body must be a JSON object' };
  }
  const { model, messages } = body;
  const systemPrompt = body.systemPrompt === undefined ? '' : body.systemPrompt;
  if (typeof model !== 'string' || !allowedModels.includes(model)) {
    return { error: `Model not allowed. Allowed: ${allowedModels.join(', ')}` };
  }
  if (typeof systemPrompt !== 'string' || systemPrompt.length > MAX_SYSTEM_CHARS) {
    return { error: 'systemPrompt must be a string of at most ' + MAX_SYSTEM_CHARS + ' characters' };
  }
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > MAX_MESSAGES) {
    return { error: `messages must be an array of 1 to ${MAX_MESSAGES} items` };
  }
  let total = 0;
  for (const m of messages) {
    if (!m || (m.role !== 'user' && m.role !== 'model') || typeof m.text !== 'string' || m.text.trim() === '') {
      return { error: 'Each message needs role "user" or "model" and non-empty text' };
    }
    total += m.text.length;
  }
  if (total > MAX_TOTAL_CHARS) return { error: 'Conversation too long' };
  if (messages[messages.length - 1].role !== 'user') {
    return { error: 'The last message must be from the user' };
  }
  return { value: { model, systemPrompt, messages } };
}

function buildGeminiRequest({ systemPrompt, messages }) {
  const body = {
    contents: messages.map((m) => ({ role: m.role, parts: [{ text: m.text }] })),
  };
  if (systemPrompt) body.systemInstruction = { parts: [{ text: systemPrompt }] };
  return body;
}

/** Text of a streamed Gemini chunk, skipping "thought" parts. */
function extractText(chunk) {
  const parts = chunk?.candidates?.[0]?.content?.parts;
  if (!Array.isArray(parts)) return '';
  return parts.filter((p) => p && p.thought !== true && typeof p.text === 'string').map((p) => p.text).join('');
}

/** A reason string if Gemini blocked the prompt or the answer, else ''. */
function blockReason(chunk) {
  const prompt = chunk?.promptFeedback?.blockReason;
  if (prompt) return `prompt blocked (${prompt})`;
  const finish = chunk?.candidates?.[0]?.finishReason;
  if (finish === 'SAFETY' || finish === 'PROHIBITED_CONTENT' || finish === 'BLOCKLIST') {
    return `answer blocked (${finish})`;
  }
  return '';
}

/** Incremental parser for Gemini's `data: {json}` SSE lines; tolerates chunks split anywhere. */
function createSseParser(onData) {
  let buffer = '';
  const handleLine = (line) => {
    const trimmed = line.replace(/\r$/, '');
    if (!trimmed.startsWith('data:')) return;
    const payload = trimmed.slice(5).trim();
    if (!payload || payload === '[DONE]') return;
    try { onData(JSON.parse(payload)); } catch { /* ignore malformed event */ }
  };
  return {
    feed(text) {
      buffer += text;
      let idx;
      while ((idx = buffer.indexOf('\n')) >= 0) {
        handleLine(buffer.slice(0, idx));
        buffer = buffer.slice(idx + 1);
      }
    },
    end() { if (buffer) handleLine(buffer); buffer = ''; },
  };
}

/** Maps a Gemini HTTP error to a stable code for the app. Upstream key problems never use 401. */
function mapUpstreamError(status, bodyText) {
  let message = '';
  try { message = JSON.parse(bodyText)?.error?.message || ''; } catch { /* not JSON */ }
  message = String(message).slice(0, 300);
  if (status === 429) return { status: 429, code: 'rate_limited', message: message || 'Gemini rate limit reached' };
  if (status === 401 || status === 403) return { status: 502, code: 'upstream_auth', message: "Gemini rejected the server's API key or permissions" };
  if (status === 404) return { status: 502, code: 'model_not_found', message: message || 'Model not found' };
  if (status === 400) return { status: 400, code: 'bad_request', message: message || 'Gemini rejected the request' };
  return { status: 502, code: 'upstream_error', message: message || `Gemini error (HTTP ${status})` };
}

module.exports = {
  MAX_MESSAGES, loadConfig, validateChatBody, buildGeminiRequest,
  extractText, blockReason, createSseParser, mapUpstreamError,
};
