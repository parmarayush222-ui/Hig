# BOT proxy

Keeps your Gemini key off the phone. The app sends chat requests here; this server adds the key and talks to Gemini.
No npm packages needed (Node 20+).

## Run locally (PC or Termux)
    cd backend
    cp .env.example .env        # then edit .env (see comments inside)
    node --env-file=.env server.js
    curl http://localhost:8080/health

The app only accepts **https** URLs, so for a phone you need either a hosted deployment (below)
or an https tunnel to your local server.

## Deploy (any Node host)
Create a web service from this repo with root directory `backend`, start command `node server.js`,
and set the environment variables from `.env.example` in the host's dashboard
(`GEMINI_API_KEY`, `BOT_APP_TOKEN`, and `TRUST_PROXY=1`). Check the host's current free-tier terms:
free instances often sleep, so the first request after idle can take a minute.

## Endpoints
- `GET /health` public, returns `{"ok":true}`
- `GET /v1/status` needs `Authorization: Bearer <BOT_APP_TOKEN>`
- `POST /v1/chat/stream` same auth; streams `data: {"text":"..."}` then `data: {"done":true}`

## Tests
    node --test
