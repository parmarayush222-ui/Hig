'use strict';

const http = require('node:http');
const crypto = require('node:crypto');
const {
  loadConfig, validateChatBody, buildGeminiRequest,
  extractText, blockReason, createSseParser, mapUpstreamError,
} = require('./lib');

const MAX_BODY_BYTES = 256 * 1024;

function createServer(cfg) {
  const hits = new Map(); // ip -> { count, windowStart }

  const tokenHash = cfg.appToken ? crypto.createHash('sha256').update(cfg.appToken).digest() : null;

  function authorized(req) {
    if (!tokenHash) return false;
    const header = req.headers['authorization'] || '';
    if (!header.startsWith('Bearer ')) return false;
    const given = crypto.createHash('sha256').update(header.slice(7)).digest();
    return crypto.timingSafeEqual(given, tokenHash);
  }

  function clientIp(req) {
    if (cfg.trustProxy) {
      const fwd = req.headers['x-forwarded-for'];
      if (typeof fwd === 'string' && fwd) return fwd.split(',')[0].trim();
    }
    return req.socket.remoteAddress || 'unknown';
  }

  function rateLimited(ip) {
    const now = Date.now();
    const entry = hits.get(ip);
    if (!entry || now - entry.windowStart >= 60000) {
      hits.set(ip, { count: 1, windowStart: now });
      return false;
    }
    entry.count += 1;
    return entry.count > cfg.rateLimitPerMin;
  }

  const sweeper = setInterval(() => {
    const now = Date.now();
    for (const [ip, e] of hits) if (now - e.windowStart >= 60000) hits.delete(ip);
  }, 60000);
  sweeper.unref();

  function json(res, status, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(status, { 'content-type': 'application/json', 'content-length': Buffer.byteLength(body) });
    res.end(body);
  }
  const fail = (res, status, code, message) => json(res, status, { error: { code, message } });

  function readBody(req) {
    return new Promise((resolve, reject) => {
      const chunks = [];
      let size = 0;
      req.on('data', (c) => {
        size += c.length;
        if (size > MAX_BODY_BYTES) { reject(new Error('too_large')); req.destroy(); return; }
        chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });
  }

  async function handleChat(req, res) {
    let parsed;
    try {
      parsed = JSON.parse(await readBody(req));
    } catch (e) {
      return fail(res, e.message === 'too_large' ? 413 : 400, 'bad_request',
        e.message === 'too_large' ? 'Request too large' : 'Body is not valid JSON');
    }
    const checked = validateChatBody(parsed, cfg.allowedModels);
    if (checked.error) return fail(res, 400, 'bad_request', checked.error);
    if (!cfg.apiKey) return fail(res, 503, 'not_configured', 'The server has no GEMINI_API_KEY configured');

    const { model, systemPrompt, messages } = checked.value;
    const ac = new AbortController();
    res.on('close', () => { if (!res.writableEnded) ac.abort(); });
    const timer = setTimeout(() => ac.abort(), cfg.upstreamTimeoutMs);
    let timedOut = false;
    ac.signal.addEventListener('abort', () => { if (!res.destroyed) timedOut = true; });

    try {
      let upstream;
      try {
        upstream = await fetch(
          `${cfg.geminiBase}/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`,
          {
            method: 'POST',
            headers: { 'content-type': 'application/json', 'x-goog-api-key': cfg.apiKey },
            body: JSON.stringify(buildGeminiRequest({ systemPrompt, messages })),
            signal: ac.signal,
          },
        );
      } catch {
        return timedOut
          ? fail(res, 504, 'timeout', 'Gemini did not answer in time')
          : fail(res, 502, 'upstream_error', 'Could not reach Gemini');
      }
      if (!upstream.ok) {
        const m = mapUpstreamError(upstream.status, await upstream.text().catch(() => ''));
        return fail(res, m.status, m.code, m.message);
      }

      res.writeHead(200, {
        'content-type': 'text/event-stream',
        'cache-control': 'no-cache',
        connection: 'keep-alive',
        'x-accel-buffering': 'no',
      });
      const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);
      let sentText = false;
      let blocked = '';
      const parser = createSseParser((chunk) => {
        const reason = blockReason(chunk);
        if (reason) blocked = reason;
        const text = extractText(chunk);
        if (text) { sentText = true; send({ text }); }
      });
      const decoder = new TextDecoder();
      try {
        for await (const part of upstream.body) parser.feed(decoder.decode(part, { stream: true }));
        parser.end();
        if (blocked && !sentText) send({ error: { code: 'blocked', message: `Gemini declined to answer: ${blocked}` } });
        else send({ done: true });
      } catch {
        send({ error: { code: timedOut ? 'timeout' : 'upstream_error', message: timedOut ? 'Gemini took too long' : 'The connection to Gemini was interrupted' } });
      }
    } finally {
      clearTimeout(timer);
      if (!res.writableEnded) res.end();
    }
  }

  return http.createServer(async (req, res) => {
    try {
      const path = (req.url || '').split('?')[0];
      if (req.method === 'GET' && path === '/health') return json(res, 200, { ok: true });

      if (!authorized(req)) return fail(res, 401, 'unauthorized', 'Missing or wrong app token');

      if (req.method === 'GET' && path === '/v1/status') {
        return json(res, 200, { ok: true, geminiConfigured: Boolean(cfg.apiKey), models: cfg.allowedModels });
      }
      if (req.method === 'POST' && path === '/v1/chat/stream') {
        if (rateLimited(clientIp(req))) return fail(res, 429, 'rate_limited', 'Too many requests, slow down');
        return await handleChat(req, res);
      }
      return fail(res, 404, 'not_found', 'Unknown endpoint');
    } catch {
      if (!res.headersSent) fail(res, 500, 'server_error', 'Unexpected server error');
      else res.end();
    }
  });
}

if (require.main === module) {
  const cfg = loadConfig(process.env);
  if (!cfg.appToken) {
    console.error('BOT_APP_TOKEN is not set. Refusing to start an unauthenticated proxy.');
    process.exit(1);
  }
  if (!cfg.apiKey) console.warn('Warning: GEMINI_API_KEY is not set. Chat requests will fail until it is.');
  createServer(cfg).listen(cfg.port, () => console.log(`BOT proxy listening on :${cfg.port}`));
}

module.exports = { createServer };
